# n8n Render Deploy

Repo mínimo para desplegar n8n en Render.
